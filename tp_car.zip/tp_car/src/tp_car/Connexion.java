package tp_car;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Connexion {
	private int port = 6075;
	private ServerSocket socket ;
	
	public Connexion() {
	
	try {
		
		
		InetAddress host = InetAddress.getLocalHost();
		socket = new ServerSocket(port,20,host);
		
	}catch(Exception ex) {
		ex.printStackTrace();
	}
	
	try {
	while(true) {
		
			Socket soc = socket.accept();
			Serveur_Ftp serveur = new Serveur_Ftp(soc);
			serveur.start();
		} 
	}catch (IOException e) {
			
			e.printStackTrace();
		}finally {
			try {
				socket.close();
			}catch(Exception ex) {
				ex.printStackTrace();
		}
	}
	}
	public static void main(String [] args) {
		Connexion con = new Connexion ();
	}
}
