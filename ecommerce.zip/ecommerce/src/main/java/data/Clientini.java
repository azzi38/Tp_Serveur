package data;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.example.ecommerce.Repository.ClientRepository;
import com.example.ecommerce.model.Client;

@Component
public class Clientini implements ApplicationRunner{
	
	  private ClientRepository repository;
	  
	  @Autowired
	    public Clientini(ClientRepository rep) {
		  repository = rep;
	  }
	  
	  @Override
	  public void run(ApplicationArguments args) throws Exception {
		  
		  long cmpt = repository.count();
		  if (cmpt == 0) {
			  Client client = new Client();
			  client.set_nomclient("azzi");
			  client.set_emails("azzirazika@gmail.com");
			  client.set_adresse("rue natioanl");
			  client.set_tel("0605827914");
			  repository.save(client);
		  }
	  }

}
