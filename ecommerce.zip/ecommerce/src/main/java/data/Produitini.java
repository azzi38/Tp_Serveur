package data;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.example.ecommerce.Repository.ProduitRepository;
import com.example.ecommerce.model.Produit;

@Component 
public class Produitini implements ApplicationRunner{
	
	  private ProduitRepository repository;
	  
	  
	  @Autowired
	    public Produitini(ProduitRepository pr) {
	        repository = pr;
	    }
	  
	  
	  @Override
	  public void run(ApplicationArguments args)  throws Exception{
		  
		  long cmpt = repository.count();
		  
		  if (cmpt==0) {
			  Produit p1 = new Produit();
			  p1.set_description("margheritta");
			  p1.set_prix(20.99);
			  p1.set_quantite(25);
			  p1.set_source("https://images.app.goo.gl/o9Mv2juWnSXTt3AE7");
			  
			  
			  
			  Produit p2 = new Produit();
			  p2.set_description("polonaise");
			  p2.set_prix(20.99);
			  p2.set_quantite(25);
			  p2.set_source("https://images.app.goo.gl/n5JGNmysNc");
			  
			  repository.save(p1);
			  repository.save(p2);
			  
		  }
		  
		  
	  }
	  

}
