package com.example.ecommerce.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import com.example.ecommerce.Repository.ProduitRepository;
import com.example.ecommerce.model.Produit;


@Controller
public class ProduitController {
	
	
	/** The product repository. */
	@Autowired
	private ProduitRepository repository;
	
	
	/**
	 * Gets all products.
	 *
	 * @return all products
	 */
	@RequestMapping(value="/toutproduit")
	public String getAll(Model model  ){
		model.addAttribute("produit",repository.findAll());
		return "produit";
		}
		
		
		
	/**
	 * Gets product.
	 *@param idproduit the id of product
	 *@param model the model 
	 * @return product if exists
	 */
	
	@RequestMapping(value="/get")
	public String get(@PathVariable  Long idproduit,Model model){
		 if(repository.findById(idproduit).isPresent()) {
			 Produit p = repository.findById(idproduit).get();
			 model.addAttribute("produit",p);
			 
		 }
		 return "produit";
	}
	
	
	
	/**
	 * Delete product.
	 *
	 * @param idproduit the id of product
	 *  @param model the model 
	 * @return string 
	 * */
	
	@RequestMapping(value="/delete")
	public String delete(Long idproduit,Model model){
		repository.deleteById(idproduit);
		model.addAttribute("produit",repository.findAll());
		return "produit";
	}
	
	/**
	 * Put product.
	 *
	 * @param idproduit the id
	 * @param model the model 
	 * @return string all products
	 */
	
	@RequestMapping(value="/put/{idproduit}")
	public String  put(@PathVariable Long idproduit, @RequestBody Produit p,Model model){
		if(repository.existsById(idproduit)) {
			repository.deleteById(idproduit);
			repository.save(p);
			model.addAttribute("produit",p);
			
		}
		return "produit";
	}
	
	
	
}
