package com.example.ecommerce.Controllers;

import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.ecommerce.Repository.ProduitRepository;
import com.example.ecommerce.model.Produit;

@Controller
public class Main {
	@Autowired
    private ProduitRepository repository;
	
	
	@RequestMapping(value="/")
	public String list(Model model ) {
		Iterable<Produit> p = repository.findAll();
		Iterator<Produit> p1 = p.iterator();
		
		int cmpt =0;
		if(p1.hasNext()) {
			Produit p2= p1.next();
			if(p2.get_quantite() >0) {
				cmpt++;
				model.addAttribute("nom",p2.get_decription());
				model.addAttribute("prix",p2.get_prix());
			}
			
		}
		model.addAttribute("cmpt",cmpt);
		return "welcome";
	}

}
