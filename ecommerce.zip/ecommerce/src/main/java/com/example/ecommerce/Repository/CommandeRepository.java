package com.example.ecommerce.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.ecommerce.model.Commande;





/**
 * The Interface CommandeRepository.
 *
 * @author azzi
 * @version 1.0
 */

@Repository
public interface CommandeRepository extends JpaRepository<Commande,Long> {

}
