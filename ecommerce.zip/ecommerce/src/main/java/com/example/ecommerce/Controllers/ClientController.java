package com.example.ecommerce.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.example.ecommerce.Repository.ClientRepository;
import com.example.ecommerce.model.Client;




public class ClientController {
	
	/** The client repository. */
	@Autowired
	private ClientRepository repository;
	
	
	/**
	 * Gets all products.
	 *
	 * @return all products
	 */
	@RequestMapping(value="/")
	public String getAll(Model model){
		model.addAttribute("client",repository.findAll());
		return "client";
		}
		
		
		
	/**
	 * Gets user.
	 *@param idclient the id of client 
	 *@param model
	 * @return user if exists
	 */
	
	@RequestMapping(value="/get")
	public String get(@PathVariable Long  idclient,Model model){
		if(repository.findById(idclient).isPresent()) {
			 Client c = repository.findById(idclient).get();
			 model.addAttribute("produit",c);
		}
		return "client";
	}
	

}
