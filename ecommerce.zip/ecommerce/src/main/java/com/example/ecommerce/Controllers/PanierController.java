package com.example.ecommerce.Controllers;

import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.ecommerce.Repository.ProduitRepository;
import com.example.ecommerce.model.Produit;

@Controller
public class PanierController {
	
	
	/** The product repository. */
	@Autowired
	private ProduitRepository repository;
	
	@RequestMapping(value="/produit", method = RequestMethod.GET)
	public String Afficher(Model model) {
		Iterable<Produit> produit = repository.findAll();
		Iterator<Produit> p =produit.iterator();
		Produit p1 = p.next();
		model.addAttribute("prix",p1.get_prix());
		model.addAttribute("disponible",p1.get_quantite());
		model.addAttribute("descreption",p1.get_decription());
		
		return "Panier";
		
	}
	

}
