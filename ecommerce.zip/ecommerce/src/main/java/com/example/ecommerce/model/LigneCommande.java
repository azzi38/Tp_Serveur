package com.example.ecommerce.model;




import javax.persistence.*;

@Entity
public class LigneCommande {
	

	private Long id;
	private Produit produit;
	private int quantite;
	private double prix;
	
	
	public LigneCommande() {};
	
	public  LigneCommande( Long id, Produit produit,int quantite,double prix) {
		this.id=id;
		this.produit = produit;
		this.quantite = quantite;
		this.prix = prix;
	}
	
	
	
	public Long get_id() {
		return this.id;
	}
	public void set_quantite(Long id) {
		this.id  = id;
	}
	
	
	public Produit get_produit() {
		return this.produit;
	}
	public void set_produit( Produit p) {
		this.produit  = p;
	}
	
	
	
	public int get_quantite() {
		return this.quantite;
	}
	public void set_quantite(int q) {
		this.quantite  = q;
	}
	
	
	public double get_prix() {
		return this.prix;
	}
	public void set_prix(double p) {
		this.prix = p;
	}

}
