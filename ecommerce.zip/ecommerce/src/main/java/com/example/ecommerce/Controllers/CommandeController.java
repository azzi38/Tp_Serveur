package com.example.ecommerce.Controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.example.ecommerce.Repository.CommandeRepository;
import com.example.ecommerce.model.Commande;


@Controller 
public class CommandeController {
	
	
	/** The order repository. */
	@Autowired
	private CommandeRepository repository;
	
	
	/**
	 * Gets all orders.
	 *
	 * @return all orders
	 */
	@RequestMapping(value="/commande")
	public String  getAll(Model model){
		model.addAttribute("commande",repository.findAll());
		return "commande";
		}
	
	
	/**
	 * Gets order.
	 *
	 **@param idcommande the id of commande
	 *@param model the model 
	 * @return order if exists
	 */
	
	@RequestMapping(value="/get")
	public String get(@PathVariable Long  idcommande ,Model model){
		if(repository.findById(idcommande).isPresent()) {
			 Commande c = repository.findById(idcommande).get();
			 model.addAttribute("produit",c);
		}
		return "commande";
	}
	

	/**
	 * Delete order.
	 *@param model 
	 * @param id the id
	 * @return all 
	 * */
	
	@RequestMapping(value="/delete")
	public String  delete(@PathVariable Long id,Model model ){
		repository.deleteById(id);
		model.addAttribute("commande",repository.findAll());
		return "commande";
	}
	
		
	

}
