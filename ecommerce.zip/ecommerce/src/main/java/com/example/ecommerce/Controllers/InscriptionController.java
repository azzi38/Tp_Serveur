package com.example.ecommerce.Controllers;

import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.ecommerce.Repository.ClientRepository;
import com.example.ecommerce.model.Client;




@Controller 
public class InscriptionController {
	
	@Autowired
	private ClientRepository repository;
	
	@RequestMapping(value="/inscription")
	public String page(Model model) {
		return "inscription";
		
		
	}
	
	@RequestMapping(value="/inscription/new", method = RequestMethod.GET)
	public String  create(HttpServletRequest r, Model model) {
		String emails = r.getParameter("emails");
		String adresse = r.getParameter("adresse");
		String name = r.getParameter("nomclient");
		String phone = r.getParameter("tel");
		Iterable<Client> client =repository.findAll();
		Iterator<Client> client1 = client.iterator();
		Client c = new Client();
		
		while(client1.hasNext()) {
			c= client1.next();
			
			if(c.get_emails().equals(emails)) {
				model.addAttribute("ok",1);
				
				return "inscrption";
			}
			
			else {
				c.set_adresse(adresse);
				c.set_emails(emails);
				c.set_nomclient(name);
				c.set_tel(phone);
				repository.save(c);
				
				return "create";
			}
				
		}
		return "ComptecreeAvecSucce";
		
	}
	
	

	
}
