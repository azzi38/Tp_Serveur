package com.example.ecommerce.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.ecommerce.model.Client;

/**
 * The Interface ClientRepository.
 *
 * @author azzi
 * @version 1.0
 */

@Repository
public interface ClientRepository extends JpaRepository <Client,Long>{

}
