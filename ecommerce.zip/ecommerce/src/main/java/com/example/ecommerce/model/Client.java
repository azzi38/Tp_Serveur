package com.example.ecommerce.model;

import java.util.Collection;

import javax.persistence.*;


@Entity 
@Table
public class Client {
	
	@Id
	private long idclient;
	private String nomclient;
	private String adresse;
	private String emails;
	private String tel;
	private Collection<Commande> commandes;
	
	
	
	public Client(long idclient,String nomclient,String adresse,String emails,String tel,Collection<Commande> commandes) {
		this.idclient=idclient;
		this.adresse = adresse;
		this.emails = emails;
		this.tel= tel;
		this.commandes = commandes;
	}
	public long get_idclient() {
		return this.idclient;
	}
	
	public void set_idcommande(long idc ) {
		this.idclient = idc;
	}
	
	
	
	public String get_nomclient() {
		return this.nomclient;
	}
	
	public void set_nomclient(String nom) {
		this.nomclient = nom;
	}
	
	
	
	public String get_adress() {
		return this.adresse;
	}
	
	public void set_adresse(String adresse ) {
		this.adresse = adresse;
	}
	
	
	/**
	 * Gets the email.
	 *
	 * @param email the new email
	 */
	public String get_emails() {
		return this.emails;
	}
	
	/**
	 * Sets the email.
	 *
	 * @param email the new email
	 */
	public void set_emails(String emails ) {
		this.emails = emails;
	}
	
	
	public String get_tel() {
		return this.tel;
	}
	
	public void set_tel(String tel ) {
		this.tel= tel;
	}
	
	
	
	public Collection<Commande> get_commande() {
		return this.commandes;
	}
	
	public void set_tel(Collection<Commande> com) {
		this.commandes= com;
	}
	

}
