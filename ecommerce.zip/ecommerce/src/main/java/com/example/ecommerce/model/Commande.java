package com.example.ecommerce.model;

import java.util.*;

import javax.persistence.*;



@Entity
public class Commande {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long idcommande;
	private Date dateCommande;
	private Client client;
	private Produit produit ;
	private Collection <LigneCommande> commande; 
	
	
	
	public Commande( Long idcommande,Date datecommande, Client client,Produit produit,Collection <LigneCommande> com) {
		this.idcommande =idcommande;
		this.dateCommande = datecommande;
		this.client = client;
		this.produit = produit ;
		this.commande = com;
	}
	
	
	public Commande() {};
	
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	
	public Long get_idcommande() {
		return this.idcommande;
	}
	
	
	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void set_idcommande(Long id ) {
		this.idcommande = id;
	}
	
	
	/**
	 * Gets the dated.
	 *
	 * @return the dated 
	 */
	public Date get_datecommande() {
		return this.dateCommande;
	}
	
	

	/**
	 * Sets the dated.
	 *
	 * @param d the new dated
	 */
	public void set_datecommande(Date d ) {
		this.dateCommande = d;
	}
	
	
	
	/**
	 * Gets the user.
	 *
	 * @return the user
	 */
	public Client get_client() {
		return this.client;
	}
	
	
	/**
	 * Sets the user.
	 *
	 * @param client the new user
	 */
	public void set_client(Client client ) {
		this.client = client;
	}
	
	
	/**
	 * Gets the product.
	 *
	 * @return the product
	 */
	public Produit get_produit() {
		return this.produit;
	}
	
	
	
	/**
	 * sets the product.
	 *
	 * @param p the new product
	 */
	public void  set_produit(Produit p) {
		 this.produit=p;
	}
	
	
	/**
	 * Gets the commande.
	 *
	 * @return the lignecommande 
	 */
	public Collection<LigneCommande> get_lignecommande() {
		return this.commande;
	}
	
	
	/**
	 * Sets the lignecommande.
	 *
	 * @param ligne the new ligneCommande 
	 */
	public Collection<LigneCommande> set_lignecommande(Collection<LigneCommande> ligne) {
		return this.commande  = ligne;
	}
	

}
