package com.example.ecommerce.model;

import java.util.*;
import javax.persistence.*;


@Entity
@Table 
public class  Panier {
	
	
	
	private Map<Long, LigneCommande> objets= new HashMap<Long,LigneCommande> ();
	
	public void addObjets(Produit p, int quantite) {
		
		LigneCommande com = objets.get(p.get_idproduit());
		
		if(com==null) {
			LigneCommande c = new LigneCommande();
			c.set_produit(p);
			c.set_quantite(quantite);
			c.set_prix(p.get_prix());
			objets.put(p.get_idproduit(),c);
			
			
		}
		else {
			com.set_quantite(com.get_quantite()+quantite);
		}
	}
	
	
	public Collection <LigneCommande >get_objets(){
		return objets.values();
	}
	
	
	public int get_size() {
		return objets.size();
	}
	
	
	public double get_total() {
		double t = 0;
		for(LigneCommande com : objets.values()) {
			t= t+com.get_prix()*com.get_quantite();
		}
		return t ;
	}
	
	
	public void delete_Objets(Long idProduit) {
		objets.remove(idProduit);
		
	}
	

}
