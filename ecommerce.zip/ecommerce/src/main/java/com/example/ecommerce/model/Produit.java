package com.example.ecommerce.model;




import java.io.Serializable;

/*import javax.persistence.GenerationType;*/
/*import javax.persistence.MappedSuperclass;*/
/*import java.util.*;*/
import javax.persistence.*;


@Entity
@Table(name="Produit")
public class Produit  implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	private Long idproduit;
	private int quantite;
	private String source;
	private double prix;
	private String description;
	
	

	public Produit() {};
	
	public Produit(Long idproduit,int quantite,String selectionne,double prix,String description) {
		this.idproduit = idproduit;
		this.quantite= quantite;
		this.source = selectionne;
		this.prix = prix;
		this.description = description;
		
	}
	
	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	
	public Long get_idproduit() {
		return this.idproduit;
	}
	
	
	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void set_idpropduit(Long id) {
		this.idproduit = id;
	}
	
	
	
	/**
	 * Gets the amount.
	 *
	 * @return the amount
	 */
	public int get_quantite() {
		return this.quantite;
	}
	
	/**
	 * Sets the amount.
	 *
	 * @param q the new amount
	 */
	public void set_quantite(int q) {
		this.quantite  = q;
	}
	
	
	
	/**
	 * Gets the selection product.
	 *
	 * @return the true if product is selected or false if not selected 
	 */
	
	public String  get_source() {
		return this.source;
	}
	
	/**
	 * Sets the source.
	 *
	 * @param b the new source
	 */
	public void set_source(String b) {
		this.source = b;
	}
	
	
	
	
	/**
	 * Gets the price.
	 *
	 * @return the price
	 */
	public double get_prix() {
		return this.prix;
	}
	
	/**
	 * Sets the price.
	 *
	 * @param p the new price
	 */
	public void set_prix(double p) {
		this.prix = p;
	}
	
	
	/**
	 * Gets the description.
	 *
	 * @return the string description
	 */
	public String get_decription() {
		return this.description;
	}
	
	/**
	 * Sets the description.
	 *
	 * @param des the new description
	 */
	public void set_description(String des) {
		this.description = des;
	}
	
	
	
	
}
