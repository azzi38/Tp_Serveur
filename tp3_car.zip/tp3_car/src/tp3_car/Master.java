package tp3_car;

import java.io.BufferedReader;
import java.io.FileReader;
import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Props;



public class Master {
	
	public void LireSend(String fichier) throws Exception{
	BufferedReader in = new BufferedReader(new FileReader("fichier"));
	String line;
	while ((line = in.readLine()) != null)
	{
      // Afficher le contenu du fichier
		  System.out.println (line);
		  
		  //envoyer le contenu du fichier
		ActorSystem system = ActorSystem.create("MySystem");
		ActorRef mapper1,mapper2 ,master;
		mapper1 = system.actorOf(Props.create(Mapper.class),"mapper1");
		mapper2 = system.actorOf(Props.create(Mapper.class),"mapper2");
		master =system.actorOf(Props.create(Master.class),"master");
		mapper1.tell(line,master);
		mapper2.tell(line,master);
	//fermer le fichier 
		in.close();

	} 

	}
}
	
	


