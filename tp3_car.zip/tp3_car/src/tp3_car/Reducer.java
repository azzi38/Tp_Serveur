package tp3_car;



public class Reducer  {

	public String [] red;
	
	public void partition(Object agr)throws Exception{
		
	}
	
	
}
