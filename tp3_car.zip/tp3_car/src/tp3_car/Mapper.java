package tp3_car;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.actor.UntypedActor;

public class Mapper extends UntypedActor{

	@Override
	public void onReceive(Object arg0) throws Exception {
		if( arg0 instanceof Mapper) {
			System.out.println("msg reçu est :"+arg0);
			ActorSystem system = ActorSystem.create("MySystem");
			ActorRef mapper , reducer;
			mapper = system.actorOf(Props.create(Mapper.class),"mapper");
			reducer = system.actorOf(Props.create(Reducer.class),"reducer");
			reducer.tell(arg0, mapper);
			
		}
		
	}

}
